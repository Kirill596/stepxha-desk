import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "STEPXHA Desk — лиды и сделки",
  description: "Личное пространство для учёта лидов, выплат и торговых сделок.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru">
      <body className="antialiased">{children}</body>
    </html>
  );
}

