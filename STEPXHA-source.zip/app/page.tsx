import Desk from "./desk";
import { getChatGPTUser,chatGPTSignInPath } from "./chatgpt-auth";
export const dynamic="force-dynamic";
export default async function Home(){
  const user=await getChatGPTUser();
  if(!user)return <main className="login"><div className="login-box"><div className="brand-icon"><img src="/stepxha-mark.svg" alt="Логотип STEPXHA"/></div><p className="eyebrow">STEPXHA / PERSONAL WORKSPACE</p><h1>Всё под контролем.</h1><p>Лиды, выплаты и журнал сделок.<br/>Одно личное пространство на всех устройствах.</p><a className="button primary" href={chatGPTSignInPath("/")} target="_top">Войти через ChatGPT <span>↗</span></a><small>Доступ к записям есть только у вас.</small></div></main>;
  return <Desk name={user.fullName||"Мой аккаунт"}/>;
}

