import { NextRequest, NextResponse } from "next/server";
import { and, eq, desc } from "drizzle-orm";
import { getDb } from "../../../db";
import { records } from "../../../db/schema";
import { getChatGPTUser } from "../../chatgpt-auth";
import { leadSchema, tradeSchema } from "../../models";
export const dynamic="force-dynamic";
const reply=(body:unknown,status=200)=>NextResponse.json(body,{status,headers:{"Cache-Control":"no-store"}});
function safeOrigin(req:NextRequest){const origin=req.headers.get("origin");return !origin || new URL(origin).host===req.headers.get("host") || new URL(origin).host===req.nextUrl.host;}
export async function GET(){
  const user=await getChatGPTUser();if(!user)return reply({error:"Войдите в аккаунт"},401);
  try{const rows=await getDb().select().from(records).where(eq(records.owner,user.userId)).orderBy(desc(records.createdAt));
    return reply({leads:rows.filter(r=>r.kind==="lead").map(r=>({id:r.id,data:JSON.parse(r.payload),updatedAt:r.updatedAt})),trades:rows.filter(r=>r.kind==="trade").map(r=>({id:r.id,data:JSON.parse(r.payload),updatedAt:r.updatedAt}))});
  }catch{ return reply({error:"Не удалось загрузить записи. Попробуйте ещё раз."},500); }
}
async function write(req:NextRequest,operation:"create"|"update"|"delete"){
  const user=await getChatGPTUser();if(!user)return reply({error:"Войдите в аккаунт"},401);
  if(!safeOrigin(req))return reply({error:"Запрос отклонён"},403);
  try{
    if(Number(req.headers.get("content-length")||0)>50000)return reply({error:"Слишком большая запись"},413);
    const body=await req.json() as {kind?:unknown;id?:unknown;data?:unknown}; const kind=body.kind;if(kind!=="lead"&&kind!=="trade")return reply({error:"Неизвестный тип записи"},400);
    const db=getDb();const id=operation==="create"?crypto.randomUUID():body.id;
    if(typeof id!=="string"||id.length>100)return reply({error:"Некорректная запись"},400);
    const where=and(eq(records.id,id),eq(records.owner,user.userId),eq(records.kind,kind));
    if(operation!=="create"){
      const existing=await db.select({id:records.id}).from(records).where(where).limit(1);
      if(!existing.length)return reply({error:"Запись уже удалена или недоступна"},404);
    }
    if(operation==="delete"){await db.delete(records).where(where);return reply({ok:true});}
    const parsed=(kind==="lead"?leadSchema:tradeSchema).safeParse(body.data);
    if(!parsed.success)return reply({error:parsed.error.issues[0]?.message||"Проверьте поля"},400);
    const updatedAt=new Date().toISOString(); const payload=JSON.stringify(parsed.data);
    if(operation==="create")await db.insert(records).values({id,owner:user.userId,kind,payload,createdAt:updatedAt,updatedAt});
    else await db.update(records).set({payload,updatedAt}).where(where);
    return reply({id,data:parsed.data,updatedAt},operation==="create"?201:200);
  }catch{return reply({error:"Не удалось сохранить изменения. Попробуйте ещё раз."},500);}
}
export const POST=(req:NextRequest)=>write(req,"create");
export const PUT=(req:NextRequest)=>write(req,"update");
export const DELETE=(req:NextRequest)=>write(req,"delete");

