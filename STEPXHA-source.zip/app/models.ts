import { z } from "zod";
const date = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(v => { const d=new Date(v+"T00:00:00Z");return Number.isFinite(d.getTime()) && d.toISOString().slice(0,10)===v; }, "Укажите корректную дату");
const amount = z.number().finite().min(0).max(1e12);
const note = z.string().max(10000);
export const leadSchema = z.object({
  date, telegram: z.string().trim().min(2).max(100), offer: z.string().trim().min(1).max(150),
  partner: z.string().max(150), source: z.string().max(150), reward: amount, payout: amount,
  status: z.enum(["new","hold","paid","rejected"]), holdUntil: z.union([date,z.literal("")]), notes:note,
});
export const tradeSchema = z.object({
  date, instrument: z.string().trim().min(1).max(50), market:z.enum(["metals","energy","forex","other"]),
  direction:z.enum(["long","short"]), status:z.enum(["open","closed"]), currency:z.enum(["USD","EUR","RUB"]),
  lots: z.number().finite().positive().max(1e9), entry: z.number().finite().positive().max(1e12),
  exit: z.union([z.number().finite().positive().max(1e12),z.null()]),
  stop: z.union([amount,z.null()]), take: z.union([amount,z.null()]),
  pnl:z.union([z.number().finite().min(-1e12).max(1e12),z.null()]), fees:amount,
  setup:z.string().max(150), notes:note,
}).superRefine((v,ctx)=>{if(v.status==="closed" && (v.exit===null || v.pnl===null))ctx.addIssue({code:"custom",message:"Для закрытой сделки укажите выход и результат"});});
export type Lead=z.infer<typeof leadSchema>;
export type Trade=z.infer<typeof tradeSchema>;
export type Row<T>={id:string; data:T; updatedAt:string};
