import { sqliteTable, text, index } from "drizzle-orm/sqlite-core";
export const records = sqliteTable("records", {
  id: text("id").primaryKey(), owner: text("owner").notNull(), kind: text("kind").notNull(),
  payload: text("payload").notNull(), createdAt: text("created_at").notNull(), updatedAt: text("updated_at").notNull(),
}, table => [index("records_owner_kind").on(table.owner, table.kind)]);
