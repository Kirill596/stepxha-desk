export type ChatMessage={role:'system'|'user'|'assistant';content:string};
const MODELS=['google/gemma-4-31b-it:free','google/gemma-4-26b-a4b-it:free'];
export class MentorError extends Error{constructor(message:string,public retryable=false){super(message);}}
export function readAnswer(data:any):string{const c=data?.choices?.[0]?.message?.content;return typeof c==='string'?c.trim():Array.isArray(c)?c.filter(x=>x?.type==='text'&&typeof x.text==='string').map(x=>x.text).join('\n').trim():'';}
export async function requestMentor(key:string,messages:ChatMessage[],signal:AbortSignal){
 let last:Error=new MentorError('AI-сервис не вернул ответ. Отчёт сохранён. Попробуй ещё раз.');
 for(let attempt=0;attempt<MODELS.length;attempt++){
  if(signal.aborted)throw new DOMException('Aborted','AbortError');
  try{
   const res=await fetch('https://openrouter.ai/api/v1/chat/completions',{method:'POST',headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify({model:MODELS[attempt],messages,max_tokens:4096,temperature:0.45,reasoning:{enabled:false,exclude:true},stream:false}),signal});
   const data=await res.json().catch(()=>null);const code=Number(data?.error?.code)||res.status;
   if(!res.ok||data?.error){
    if(code===401)throw new MentorError('Ключ недействителен. Нажми «Отключить», затем подключи ИИ снова.');
    if(code===429)throw new MentorError('Достигнут бесплатный лимит OpenRouter. Попробуй позже. Платные модели не используются.');
    if(code===402)throw new MentorError('OpenRouter отклонил запрос из-за лимита ключа или аккаунта. Сохрани лимит расходов $0; платный режим не нужен. Проверь бесплатный доступ в OpenRouter.');
    if(code===403)throw new MentorError('OpenRouter запретил этот запрос. Проверь доступность сервиса в своей сети и настройки провайдеров OpenRouter. Отчёт сохранён.');
    throw new MentorError('Бесплатная модель временно недоступна. Отчёт сохранён; попробуй ещё раз.',true);
   }
   const text=readAnswer(data);
   if(!text)throw new MentorError('Модель вернула пустой ответ. Попробуй ещё раз — отчёт сохранён.',true);
   return {text,model:data.model||MODELS[attempt],truncated:data.choices?.[0]?.finish_reason==='length'};
  }catch(e){const err=e as Error;if(err.name==='AbortError')throw err;if(err instanceof MentorError&&!err.retryable)throw err;last=err instanceof TypeError?new MentorError('Нет соединения с OpenRouter из этого браузера или сети. Отчёт сохранён. Открой openrouter.ai в том же браузере и повтори запрос.',true):err;if(attempt===MODELS.length-1)throw last;}
 }
 throw last;
}
